console.log('بدء التشغيل 🚀🚀🚀') 
import cfonts from 'cfonts';
import chalk from 'chalk';

cfonts.say('بوت البولبول 🐧', {
  font: 'chrome',
  align: 'center',
  gradient: ['blue', 'green'],
  transition: false
});

cfonts.say('بواسطة: بلال الزفتاوي', {
  font: 'console',
  align: 'center',
  gradient: ['blue', 'green'],
  transition: false
});

console.log(chalk.cyan('الرقم: 01019239586'));
console.log(chalk.yellow('تم تطوير البوت ليعمل بكفاءة على منصة OptikLink'));

//console.clear();

import('./main.js');
