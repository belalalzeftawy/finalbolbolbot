import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import fs from 'fs'

//owner - المالك
global.owner = [
['201019239586'],  // بلال الزفتاوي
['201019239586']
]

//معلومات البوت 
globalThis.info = {
wm: "بوت البولبول 🐧",
vs: "2.0.0-beta",
packname: "ملصقات عربية 🐧 - بوت البولبول\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n",
author: "المطور: بلال الزفتاوي\n• الرقم: 01019239586",
apis: "https://api.delirius.store",
apikey: "GataDios",
fgmods: { url: 'https://api.fgmods.xyz/api', key: 'elrebelde21' },
neoxr: { url: 'https://api.neoxr.eu/api', key: 'GataDios' },
img2: "https://telegra.ph/file/39fb047cdf23c790e0146.jpg",
img4: null, // تم حذف الصور غير المناسبة
yt: "https://www.youtube.com/@bilal_alzaftawi",
tiktok: "https://www.tiktok.com/@bilal_alzaftawi",
md: "https://github.com/bilal-alzaftawi/Arabic-WhatsApp-Bot",
fb: "https://www.facebook.com/bilal.alzaftawi",
ig: "https://www.instagram.com/bilal_alzaftawi",
nn: "https://chat.whatsapp.com/HNDVUxHphPzG3cJHIwCaX5", //مجموعة رسمية 1
nn2: "https://chat.whatsapp.com/KDBt6S54riRCIpSZspkxhg", //مجموعة رسمية 2
nn3: "https://chat.whatsapp.com/GXNXKWSEckU1j1c7sItTxK", //تعاون البولبول
nn4: "https://chat.whatsapp.com/Em4Byf4w5VgHObPvZQlfnM", //رابط بوت البولبول
nn5: "https://chat.whatsapp.com/J5hQvECqR4W6uTT84uiSBx", //دعم تقني
nn6: "https://chat.whatsapp.com/ILAHJeZsHh973tQ96i2aqS", //دعم المطورين 
nna: "https://whatsapp.com/channel/0029Vah0NnV6mYPDQI7bpt0z",
nna2: "https://whatsapp.com/channel/0029Vah0NnV6mYPDQI7bpt0z"
}

//----------------------------------------------------

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
