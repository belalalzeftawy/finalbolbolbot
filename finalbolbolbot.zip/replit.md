# Overview

بوت البولبول 🐧 is a WhatsApp bot built with Node.js and Baileys, designed specifically for Arabic users by Bilal Al-Zaftawi (01019239586). The bot provides comprehensive features in Arabic language including downloads, entertainment, AI interactions, group management, and is optimized for OptikLink hosting platform. All inappropriate images have been removed and the bot displays everything in console-only mode with QR code authentication using creds.json session persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Core Framework
- **Runtime**: Node.js with ES6 modules
- **WhatsApp Interface**: Baileys library for WhatsApp Web API integration
- **Language**: JavaScript with async/await patterns
- **Bot Architecture**: Event-driven plugin system with hot-reload capabilities

## Database Layer
- **Primary Database**: PostgreSQL for persistent data storage
- **Connection Management**: Direct PostgreSQL client with connection pooling
- **Schema**: Automated table creation with dynamic column addition
- **Data Models**: User profiles, group settings, chat memory, and bot configurations

## Plugin System
- **Structure**: Modular plugin architecture with automatic loading
- **Hot Reload**: Dynamic plugin reloading without bot restart
- **Command Handling**: Dot-prefix command system (.) for all commands
- **Event Hooks**: Before/after command execution hooks for middleware functionality

## Multi-Bot Support
- **Sub-bot System**: Dynamic sub-bot creation with individual sessions
- **Session Management**: File-based session storage in separate directories
- **QR Code/Phone Auth**: Dual authentication methods for bot deployment
- **Instance Isolation**: Independent configurations per bot instance

## Media Processing
- **Converters**: FFmpeg-based audio/video conversion utilities
- **File Handling**: Multi-format support with automatic type detection
- **Upload Services**: Multiple file hosting integrations (qu.ax, catbox, etc.)
- **Sticker Generation**: WebP creation with ImageMagick/FFmpeg

## Content Moderation
- **Anti-link System**: Configurable link detection and removal
- **Anti-fake**: Country-based number filtering
- **Anti-profanity System**: Arabic profanity filter with 5-warning system and Quranic verse warnings
- **Auto-response**: AI-powered chat responses with memory
- **Spam Protection**: Rate limiting and user request tracking

## AI Integration
- **Multiple Providers**: BlackBox AI, Perplexity, and custom scrapers
- **Context Memory**: Chat history persistence with configurable TTL
- **Auto-leveling**: XP-based user progression system
- **Smart Responses**: Context-aware automatic replies

# External Dependencies

## Core Services
- **Baileys**: WhatsApp Web API client
- **PostgreSQL**: Primary database with optional dependency handling
- **FFmpeg**: Media processing and conversion
- **ImageMagick**: Image manipulation for stickers

## Download APIs
- **YouTube**: Multiple API providers (SaveTube, OGMP3, YT-DLP alternatives)
- **Social Media**: Instagram, TikTok, Facebook, Threads downloaders
- **File Hosting**: MediaFire, Google Drive, GitHub repository cloning
- **Music Services**: Spotify and Apple Music integration

## Media APIs
- **Image Search**: Google Images, Pinterest search
- **Content APIs**: Multiple fallback providers for reliability
- **Upload Services**: qu.ax, catbox, uguu, pixeldrain for file hosting

## AI Services
- **BlackBox AI**: Primary AI provider for chat responses
- **Neoxr API**: Backup AI service
- **Custom Scrapers**: Fallback AI implementations

## Utilities
- **QR Generation**: qrcode library for bot authentication
- **Text Processing**: Similarity matching for games and commands
- **Caching**: Node-cache for temporary data storage
- **Logging**: Custom logging system with multiple levels