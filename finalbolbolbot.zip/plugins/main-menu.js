import moment from 'moment-timezone'
import { xpRange } from '../lib/levelling.js'
import { db } from '../lib/postgres.js'
import fs from "fs";

const cooldowns = new Map()
const COOLDOWN_DURATION = 180000

const tags = {
main: 'ℹ️ معلومات البوت',
jadibot: '✨ بوت فرعي',
downloader: '🚀 التحميلات',
game: '👾 الألعاب',
religion: '🕌 الأوامر الدينية',
gacha: '✨️ جديد - آر بي جي',
rg: '🟢 التسجيل',
group: '⚙️ إدارة المجموعة',
nable: '🕹 تفعيل/تعطيل',
nsfw: '🥵 أوامر +18',
buscadores: '🔍 البحث',
sticker: '🧧 الملصقات',
econ: '🛠 آر بي جي',
convertidor: '🎈 المحولات',
logo: '🎀 الشعارات',
tools: '🔧 الأدوات',
randow: '🪄 عشوائي',
efec: '🎙 تأثيرات صوتية',
owner: '👑 المالك'
}

const defaultMenu = {
before: `╔══════════════════════════════╗
║        🐧 بوت البولبول 🐧        ║
╚══════════════════════════════╝

أهلاً وسهلاً 🚀 *%name*

📅 التاريخ: *%fecha*
🕰️ الوقت: *%hora* 🇪🇬
👥 المستخدمين: *%totalreg*
⏱️ مدة التشغيل: *%muptime*
📌 حدك اليومي: *%limit*
🎆 مستواك: *%level* | خبرتك: *%exp*

%botOfc

🎉 *مرحباً بك في عالم بوت البولبول!*
بوت مصمم خصيصاً للمجموعات العربية 🎆

💬 *يمكنك التحدث معي:* @%BoTag ما هو الذكاء الاصطناعي؟

╔══════════════════════════════╗
║    📢 طريقة استخدام البوت    ║
╚┳─────────────────────────────╝
 • استخدم نقطة (.) قبل الأوامر
 • أو اكتب بس "الاوامر" للقائمة
 • مثال: .play أو .يوتيوب
`.trimStart(),
  header: '╔══════════════════════════════╗\n║       %category       ║\n╚══════════════════════════════╝',
  body: ' • %cmd %islimit %isPremium',
  footer: '\n╚══════════════════════════════╝\n',
  after: `\n\n╔══════════════════════════════╗\n║        📨 نصائح مهمة 📨        ║\n╚══════════════════════════════╝\n\n🌟 *هل تريد بوتاً فرعياً خاصاً بك؟*\nاستخدم الأمر: *.serbot*\n\n🎵 *للاستماع للمقاطع الصوتية:*\nاستخدم الأمر: *.audios*\n\n🔥 *طوره بلال الزفتاوي - 01019239586*\n\n╔══════════════════════════════╗\n║     ✨ استمتع بالبوت! ✨     ║\n╚══════════════════════════════╝`
}

const handler = async (m, { conn, usedPrefix: _p, args }) => {
const chatId = m.key?.remoteJid;
const now = Date.now();
const chatData = cooldowns.get(chatId) || { lastUsed: 0, menuMessage: null };
const timeLeft = COOLDOWN_DURATION - (now - chatData.lastUsed);

if (timeLeft > 0) {
try {
const senderTag = m.sender ? `@${m.sender.split('@')[0]}` : '@usuario';
await conn.reply(chatId, `⚠️ مرحباً ${senderTag}، القائمة موجودة أعلاه 🙄\n> سيتم إرسالها كل 3 دقائق لتجنب الإزعاج، اقرأها من الأعلى. 👆`, chatData.menuMessage || m);
} catch (err) {
return;
}
return;
}

const name = m.pushName || 'sin name';
const fecha = moment.tz('America/Argentina/Buenos_Aires').format('DD/MM/YYYY');
const hora = moment.tz('America/Argentina/Buenos_Aires').format('HH:mm:ss');
const _uptime = process.uptime() * 1000;
const muptime = clockString(_uptime);

let user;
try {
const userRes = await db.query(`SELECT * FROM usuarios WHERE id = $1`, [m.sender]);
user = userRes.rows[0] || { limite: 0, level: 0, exp: 0, role: '-' };
} catch (err) {
user = { limite: 0, level: 0, exp: 0, role: '-' };
}

let totalreg = 0;
let rtotalreg = 0;
try {
const userCountRes = await db.query(`
      SELECT COUNT(*)::int AS total,
             COUNT(*) FILTER (WHERE registered = true)::int AS registrados
      FROM usuarios
    `);
totalreg = userCountRes.rows[0].total;
rtotalreg = userCountRes.rows[0].registrados;
} catch (err) {
}
const toUsers = toNum(totalreg);
const toUserReg = toNum(rtotalreg);
const nombreBot = conn.user?.name || 'Bot'
const isPrincipal = conn === global.conn;
const tipo = isPrincipal ? 'البوت الرئيسي' : 'بوت فرعي';
let botOfc = '';
let BoTag = "";
if (conn.user?.id && global.conn?.user?.id) {
const jidNum = conn.user.id.replace(/:\d+/, '').split('@')[0];
botOfc = (conn.user.id === global.conn.user.id) ? `*• البوت الأساسي:* wa.me/${jidNum}` : `*• بوت فرعي من:* wa.me/${global.conn.user.id.replace(/:\d+/, '').split('@')[0]}`;
BoTag = jidNum;
}

const multiplier = "750" || 1.5;
const { min, xp, max } = xpRange(user.level || 0, multiplier);

const help = Object.values(global.plugins).filter(p => !p.disabled).map(plugin => ({
help: Array.isArray(plugin.help) ? plugin.help : [plugin.help],
tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
prefix: 'customPrefix' in plugin,
limit: plugin.limit,
premium: plugin.premium
}));

// ترجمة الفئات العربية للإنجليزية
const arabicToEnglish = {
  'معلومات': 'main',
  'تحميل': 'downloader', 'تحميلات': 'downloader', 'داونلود': 'downloader',
  'العاب': 'game', 'ألعاب': 'game', 'لعب': 'game', 'جيم': 'game',
  'ملصقات': 'sticker', 'ستيكر': 'sticker', 'ستيكرات': 'sticker',
  'المجموعة': 'group', 'جروب': 'group', 'مجموعة': 'group', 'ادارة': 'group',
  'محولات': 'convertidor', 'تحويل': 'convertidor', 'كونفرت': 'convertidor',
  'بحث': 'buscadores', 'البحث': 'buscadores', 'سيرش': 'buscadores',
  'ديني': 'religion', 'دينية': 'religion', 'إسلامي': 'religion',
  'مرح': 'fun', 'ترفيه': 'fun', 'فان': 'fun',
  'مالك': 'owner', 'اونر': 'owner', 'أدمن': 'owner'
};

const categoryRequested = args[0]?.toLowerCase();
const mappedCategory = categoryRequested && arabicToEnglish[categoryRequested] ? arabicToEnglish[categoryRequested] : categoryRequested;
const validTags = mappedCategory && tags[mappedCategory] ? [mappedCategory] : Object.keys(tags);
let text = defaultMenu.before;

for (const tag of validTags) {
const comandos = help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help);
if (!comandos.length) continue;

text += '\n' + defaultMenu.header.replace(/%category/g, tags[tag]) + '\n';
for (const plugin of comandos) {
for (const helpCmd of plugin.help) {
text += defaultMenu.body
.replace(/%cmd/g, plugin.prefix ? helpCmd : _p + helpCmd)
.replace(/%islimit/g, plugin.limit ? '(💎)' : '')
.replace(/%isPremium/g, plugin.premium ? '(💵)' : '') + '\n';
}}
text += defaultMenu.footer;
}
text += defaultMenu.after;

const replace = {
'%': '%', p: _p, name,
limit: user.limite || 0,
level: user.level || 0,
role: user.role || '-',
totalreg, rtotalreg, toUsers, toUserReg,
exp: (user.exp || 0) - min,
maxexp: xp,
totalexp: user.exp || 0,
xp4levelup: max - (user.exp || 0),
fecha, hora, muptime,
wm: (global.info && global.info.wm) || 'بوت البولبول 🐧',
botOfc: botOfc,
BoTag: BoTag,
nna2: (global.info && global.info.nna2) || 'https://chat.whatsapp.com/'
};

text = String(text).replace(new RegExp(`%(${Object.keys(replace).join('|')})`, 'g'), (_, key) => replace[key] ?? '');
try {
const menuMessage = await conn.sendMessage(chatId, { text: text, contextInfo: { forwardedNewsletterMessageInfo: { newsletterJid: "120363305025805187@newsletter",newsletterName: "بوت البولبول 🐧" }, forwardingScore: 999, isForwarded: true, mentionedJid: await conn.parseMention(text), externalAdReply: { mediaUrl: (() => {
  const urls = [(global.info && global.info.nna), (global.info && global.info.nna2), (global.info && global.info.md)].filter(Boolean);
  return urls.length > 0 ? urls[Math.floor(Math.random() * urls.length)] : 'https://telegra.ph/file/7d1d7f7d8fc7b6b4b2a4b.jpg';
})(), mediaType: 2, showAdAttribution: false, renderLargerThumbnail: false, title: "✨️ قائمة الأوامر ✨️", body: `${nombreBot} - بوت البولبول 🐧`, thumbnailUrl: (global.info && global.info.img2) || '', sourceUrl: "https://skyultraplus.com" }}}, { quoted: m });
cooldowns.set(chatId, { lastUsed: now, menuMessage: menuMessage })
m.react('🙌');
} catch (err) {    
m.react('❌')
console.error(err);
}}
handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu|help|allmenu|menú|الاوامر|اوامر|أوامر|الأوامر|قائمة)$/i
handler.customPrefix = /^(?:\.?|)\s*(?:الاوامر|اوامر|أوامر|الأوامر|قائمة)$/i
export default handler

const clockString = ms => {
  const h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  const m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  const s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

const toNum = n => (n >= 1_000_000) ? (n / 1_000_000).toFixed(1) + 'M'
  : (n >= 1_000) ? (n / 1_000).toFixed(1) + 'k'
  : n.toString()