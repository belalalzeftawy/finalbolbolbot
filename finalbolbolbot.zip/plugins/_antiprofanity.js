import { db } from '../lib/postgres.js';

// قائمة الكلمات المحظورة
const bannedWords = [
    'كسمك', 'متناك', 'معرص', 'علق', 'زاني', 'متقحبن', 'لبوه', 'ببيتناك', 
    'بتتناك', 'ناك', 'نيك', 'متاخد', 'اللبوه', 'سكس', 'كسك', 'كسها', 
    'عرص', 'احبه', 'خول', 'معرس', 'قحبه', 'ابن الوسخه', 'منيوك', 
    'ابن الكلب', 'ابن المتناكه', 'طيز', 'شرموط', 'شرموطه'
];

const maxwarn = 5; // الحد الأقصى للتحذيرات قبل الطرد
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

export async function before(m, { conn }) {
    if (!m.isGroup || !m.originalText) return;
    
    const userTag = `@${m.sender.split('@')[0]}`;
    const messageText = m.originalText.toLowerCase();
    
    // التحقق من تفعيل النظام في المجموعة
    try {
        const res = await db.query('SELECT antiprofanity FROM group_settings WHERE group_id = $1', [m.chat]);
        const config = res.rows[0];
        if (!config || !config.antiprofanity) return;
    } catch (e) {
        console.error(e);
        return;
    }
    
    // التحقق من وجود كلمات محظورة
    const containsProfanity = bannedWords.some(word => messageText.includes(word.toLowerCase()));
    if (!containsProfanity) return;
    
    // التحقق من صلاحيات البوت والمرسل
    const metadata = await conn.groupMetadata(m.chat);
    const botId = conn.user?.id?.replace(/:\d+@/, "@");
    const isBotAdmin = metadata.participants.some(p => p.id === botId && p.admin);
    const isSenderAdmin = metadata.participants.some(p => p.id === m.sender && p.admin);
    
    // لا نحذر المشرفين أو رسائل البوت نفسه
    if (isSenderAdmin || m.fromMe) return;
    
    try {
        // حذف الرسالة المسيئة أولاً
        const bang = m.key.id;
        const delet = m.key.participant || m.sender;
        
        if (isBotAdmin) {
            await conn.sendMessage(m.chat, { 
                delete: { 
                    remoteJid: m.chat, 
                    fromMe: false, 
                    id: bang, 
                    participant: delet 
                }
            });
        }
        
        // التحقق من وجود المستخدم في قاعدة البيانات
        let userResult = await db.query('SELECT * FROM usuarios WHERE id = $1', [m.sender]);
        
        // إنشاء سجل للمستخدم إذا لم يكن موجوداً
        if (!userResult.rows.length) {
            await db.query(`
                INSERT INTO usuarios (id, nombre, warn) 
                VALUES ($1, $2, 0)
                ON CONFLICT (id) DO NOTHING
            `, [m.sender, userTag]);
            userResult = await db.query('SELECT * FROM usuarios WHERE id = $1', [m.sender]);
        }
        
        let currentWarnings = userResult.rows[0]?.warn || 0;
        
        if (currentWarnings < maxwarn) {
            // إضافة تحذير جديد
            await db.query('UPDATE usuarios SET warn = warn + 1 WHERE id = $1', [m.sender]);
            currentWarnings += 1;
            
            // رسالة التحذير مع الآية الكريمة
            const warningMessage = `*⚠️ تحذير - كلمات غير مناسبة ⚠️*\n\n${userTag} تم اكتشاف استخدام كلمات غير مناسبة في رسالتك\n\n*• عدد التحذيرات:* ${currentWarnings}/${maxwarn}\n*• التحذير:* استخدام ألفاظ غير لائقة\n\n*تذكر:*\n﴿وَاتَّقُوا يَوْمًا تُرْجَعُونَ فِيهِ إِلَى اللَّٰهِ﴾\n\n_إذا وصلت إلى ${maxwarn} تحذيرات ستتم إزالتك من المجموعة_`;
            
            await conn.sendMessage(m.chat, { 
                text: warningMessage, 
                mentions: [m.sender] 
            }, { quoted: m });
            
        } else {
            // طرد المستخدم وإعادة تعيين التحذيرات
            await db.query('UPDATE usuarios SET warn = 0 WHERE id = $1', [m.sender]);
            
            const kickMessage = `*🚫 تم طرد المستخدم 🚫*\n\n${userTag} تجاوز الحد المسموح من التحذيرات (${maxwarn}) وسيتم إزالته من المجموعة\n\n*السبب:* الاستمرار في استخدام ألفاظ غير لائقة\n\n﴿وَاتَّقُوا يَوْمًا تُرْجَعُونَ فِيهِ إِلَى اللَّٰهِ﴾`;
            
            await conn.sendMessage(m.chat, { 
                text: kickMessage, 
                mentions: [m.sender] 
            }, { quoted: m });
            
            // انتظار 3 ثواني ثم الطرد
            await delay(3000);
            
            if (isBotAdmin) {
                await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            } else {
                await conn.sendMessage(m.chat, {
                    text: `*تنبيه:* لا يمكنني طرد ${userTag} لأنني لست مشرفاً في المجموعة`
                });
            }
        }
        
    } catch (err) {
        console.error('خطأ في نظام حظر الكلمات:', err);
    }
}