// عجلة الحظ
const handler = async (m, { conn }) => {
  const prizes = [
    '🎁 مكافأة رائعة!', '💎 جوهرة نادرة!', '🏆 كأس الفائز!',
    '🎯 هدف محقق!', '⭐ نجمة ذهبية!', '🎊 احتفال!',
    '💫 حظ عظيم!', '🌟 فرصة ذهبية!'
  ];
  
  const prize = prizes[Math.floor(Math.random() * prizes.length)];
  
  // محاكاة دوران العجلة
  const spinning = ['🎰', '🔄', '⚡', '✨'];
  let currentMsg = '🎰 *دوران العجلة...*';
  await conn.reply(m.chat, currentMsg, m);
  
  // تأثير الدوران
  for (let i = 0; i < 3; i++) {
    await new Promise(resolve => setTimeout(resolve, 800));
    const spinChar = spinning[Math.floor(Math.random() * spinning.length)];
    currentMsg = `${spinChar} *جاري الدوران...*`;
  }
  
  await new Promise(resolve => setTimeout(resolve, 800));
  
  const finalMessage = `╔══════════════════════════════╗
║        🎰 عجلة الحظ 🎰        ║
╚══════════════════════════════╝

🎊 *تهانينا!* فزت بـ:

${prize}

╔══════════════════════════════╗
║      🍀 حظك اليوم رائع! 🍀      ║
╚══════════════════════════════╝`;
  
  await conn.reply(m.chat, finalMessage, m);
};

handler.help = ['حظ'];
handler.tags = ['game'];  
handler.command = /^(حظ|عجلة|lucky|حظك)$/i;

export default handler;