import { db } from '../lib/postgres.js';

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply('❌ هذا الأمر يعمل في المجموعات فقط');
    
    // التحقق من إعدادات المجموعة
    try {
        let result = await db.query('SELECT * FROM group_settings WHERE group_id = $1', [m.chat]);
        
        if (!result.rows.length) {
            // إنشاء إعدادات جديدة للمجموعة إذا لم تكن موجودة
            await db.query(`
                INSERT INTO group_settings (group_id, antiprofanity) 
                VALUES ($1, true)
                ON CONFLICT (group_id) DO UPDATE SET antiprofanity = true
            `, [m.chat]);
        }
        
        const action = args[0]?.toLowerCase();
        
        if (action === 'تشغيل' || action === 'on' || action === 'فعل') {
            await db.query('UPDATE group_settings SET antiprofanity = true WHERE group_id = $1', [m.chat]);
            await m.reply('✅ *تم تفعيل نظام منع الكلمات المسيئة*\n\n• سيتم تحذير المستخدمين عند استخدام كلمات غير لائقة\n• بعد 5 تحذيرات سيتم طردهم من المجموعة\n• الآية الكريمة ستظهر مع كل تحذير\n\n﴿وَاتَّقُوا يَوْمًا تُرْجَعُونَ فِيهِ إِلَى اللَّٰهِ﴾');
            
        } else if (action === 'إيقاف' || action === 'off' || action === 'عطل') {
            await db.query('UPDATE group_settings SET antiprofanity = false WHERE group_id = $1', [m.chat]);
            await m.reply('❌ *تم إيقاف نظام منع الكلمات المسيئة*\n\nلن يتم تحذير المستخدمين عند استخدام كلمات غير لائقة');
            
        } else {
            // عرض الحالة الحالية
            result = await db.query('SELECT antiprofanity FROM group_settings WHERE group_id = $1', [m.chat]);
            const isEnabled = result.rows[0]?.antiprofanity || false;
            
            const statusMessage = `*🛡️ حالة نظام منع الكلمات المسيئة*\n\n*الحالة الحالية:* ${isEnabled ? '✅ مفعل' : '❌ معطل'}\n\n*الاستخدام:*\n• \`.${command} تشغيل\` - لتفعيل النظام\n• \`.${command} إيقاف\` - لإيقاف النظام\n\n*معلومات النظام:*\n• عدد التحذيرات المسموحة: 5\n• يتم طرد المستخدم بعد تجاوز الحد\n• لا يؤثر على المشرفين\n\n﴿وَاتَّقُوا يَوْمًا تُرْجَعُونَ فِيهِ إِلَى اللَّٰهِ﴾`;
            
            await m.reply(statusMessage);
        }
        
    } catch (err) {
        console.error('خطأ في إعدادات نظام منع الكلمات:', err);
        await m.reply('❌ حدث خطأ في النظام');
    }
};

handler.help = ['منع-كلمات [تشغيل/إيقاف]'];
handler.tags = ['group'];
handler.command = /^(منع-كلمات|منع_كلمات|antiprofanity|كلمات-مسيئة)$/i;
handler.group = true;
handler.admin = true;
handler.register = true;

export default handler;