// لعبة تخمين الرقم
const activeGames = new Map();

const handler = async (m, { conn }) => {
  const chatId = m.chat;
  const number = Math.floor(Math.random() * 100) + 1;
  
  activeGames.set(chatId, { number, attempts: 0, startTime: Date.now() });
  
  const message = `╔══════════════════════════════╗
║      🎯 لعبة تخمين الرقم 🎯      ║
╚══════════════════════════════╝

🎮 *تحدي جديد بدأ!*

🔢 خمن رقم من 1 إلى 100
⏰ لديك محاولات غير محدودة
💡 سأعطيك تلميحات

*اكتب رقمك في الشات...*

╔══════════════════════════════╗
║        🎉 حظاً موفقاً! 🎉        ║
╚══════════════════════════════╝`;

  await conn.reply(chatId, message, m);
};

// معالج للأرقام
export async function before(m, { conn }) {
  if (m.isBaileys || !m.text) return;
  
  const chatId = m.chat;
  const game = activeGames.get(chatId);
  
  if (!game) return;
  
  const guess = parseInt(m.text);
  if (isNaN(guess) || guess < 1 || guess > 100) return;
  
  game.attempts++;
  
  if (guess === game.number) {
    const timeSpent = Math.floor((Date.now() - game.startTime) / 1000);
    activeGames.delete(chatId);
    
    const message = `🎊 *تهانينا! فزت!* 🎊

🎯 الرقم الصحيح: *${game.number}*
🔥 عدد المحاولات: *${game.attempts}*
⏱️ الوقت المستغرق: *${timeSpent} ثانية*

${game.attempts <= 5 ? '🏆 أداء ممتاز!' : game.attempts <= 10 ? '👏 أداء جيد!' : '💪 مجهود رائع!'}

اكتب *.رقم* للعب مرة أخرى!`;
    
    await conn.reply(chatId, message, m);
  } else if (guess < game.number) {
    await conn.reply(chatId, `📈 *أعلى من ${guess}*\n\n🔥 المحاولة ${game.attempts}\n💡 جرب رقماً أكبر!`, m);
  } else {
    await conn.reply(chatId, `📉 *أقل من ${guess}*\n\n🔥 المحاولة ${game.attempts}\n💡 جرب رقماً أصغر!`, m);
  }
  
  return true; // منع معالجة الرسالة كأمر عادي
}

handler.help = ['رقم'];
handler.tags = ['game'];
handler.command = /^(رقم|تخمين|guess)$/i;

export default handler;